#!/bin/bash

# Variables
TOMCAT_WEBAPPS="/opt/tomcat/webapps"
PROJECT_NAME="CitasM"
WAR_FILE="${PROJECT_NAME}.war"

echo "Deteniendo Tomcat..."
sudo systemctl stop tomcat

echo "Copiando WAR al directorio de despliegue..."
sudo cp $WAR_FILE $TOMCAT_WEBAPPS/

echo "Iniciando Tomcat..."
sudo systemctl start tomcat

echo "Despliegue completo. Accede a: http://<TU-IP-EC2>:8080/${PROJECT_NAME}"
